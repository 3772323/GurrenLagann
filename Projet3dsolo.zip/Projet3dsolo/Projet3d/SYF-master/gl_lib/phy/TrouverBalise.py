import os
from PIL import Image
import math
import numpy 

class TrouverBalise() :
    def __init__(self):
        self.x=0
        self.y=0
        self.z=0

    def trouverBalise(self,image):
        img=image
        (height ,width) = img.size
        i=0
        j=0
        cptv=0
        moy_v  = (0,0) 
        while j < width :
            i=0
            while i < height :
                (rouge,vert,bleu) = img.getpixel((i,j))
                if vert > 110 and rouge < vert and bleu < 2/3 * vert:
                    moy_v=(moy_v[0]+i , moy_v[1] +j)
                    cptv+=1
                i=i+1
            j=j+1
        moy_v=(moy_v[0]/cptv,moy_v[1]/cptv)
        print( moy_v )




            
img = Image.open('/users/nfs/Etu7/3302297/Documents/2i013/Projet3dsolo/Projet3d/SYF-master/gl_lib/phy/solovert-1.jpg')
d=Direction()
d.trouverBalise(img)
img.show()
