from . import d2
from . import d3

__all__=["deuxD", "troisD"]