class Vue2D(object):
    """
    Classe abstraite defisissant les methodes des vues 2D
    """
    def __init__(self):
        pass
    
    def afficher(self, canvas):
        pass
    







        


